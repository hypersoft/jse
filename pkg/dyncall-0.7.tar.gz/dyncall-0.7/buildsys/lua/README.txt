This helper folder is used to bootstrap lua on platforms where there
is no lua at all.


