-- user config for rand-sig.lua:
minargs  = 0
maxargs  = 32
ncases   = 100
types    = "csijlpfd"

